import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import streamlit as st

# Charger le fichier Excel dans un dataframe pandas
df = pd.read_excel("Classeur1.xlsx")

# Sélectionner les colonnes de prix unitaire et de quantité
X = df.iloc[:, 2].values.reshape(-1, 1)
y = df.iloc[:, 6].values.reshape(-1, 1)

# Effectuer la régression linéaire
reg = LinearRegression().fit(X, y)

# Prédire les valeurs de prix unitaire à partir des quantités
y_pred = reg.predict(X)

# Afficher les coefficients de la droite de régression
st.write('Coefficients : \n', reg.coef_)

# Tracer le graphique des données et de la droite de régression
fig, ax = plt.subplots()
ax.scatter(X, y, color='blue')
ax.plot(X, y_pred, color='red', linewidth=2)
ax.set_title('Régression linéaire')
ax.set_xlabel('Prix unitaire')
ax.set_ylabel('Quantité')
st.pyplot(fig)