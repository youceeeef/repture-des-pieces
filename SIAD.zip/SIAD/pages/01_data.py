import pandas as pd
import streamlit as st
import webbrowser

# Read the Excel file into a pandas DataFrame
df = pd.read_excel("Classeur1.xlsx")

# Display the contents of the DataFrame in Streamlit
st.write("## data!")
st.write(df)

@st.cache
def load_data(file_path):
    return pd.read_excel(file_path)

#ajouter une donnée
def add_row(df, ART, LIB, Prix_unitaire, MVT, DTMVT, Type, QTEMVT, MAG):
    new_row = [ART, LIB, Prix_unitaire, MVT, DTMVT, Type, QTEMVT, MAG]
    df = df.append(pd.Series(new_row, index=df.columns), ignore_index=True)
    return df

#modifier une donée
#suprimer une donnée
def remove_row(df):
    selected_row = st.dataframe(df.style.highlight_null(null_color='red'))
    if callable(selected_row):
        df = selected_row().data
    if isinstance(selected_row, pd.DataFrame):
        index = selected_row.index[0]
        df = df.drop(index)
    return df

def write_data(df, file_path):
    df.to_excel(file_path, index=False)

def main():
    file_path = 'Classeur1.xlsx'
    df = load_data(file_path)
    
    #crée les text field de donnée
    
    
        
    ART = st.text_input('ART',value="")
    LIB = st.text_input('LIB',value="")
    Prix_unitaire = st.number_input('Prix unitaire de cession')
    MVT = st.number_input('MVT',step=1)
    DTMVT = st.text_input('DTMVT',value='aaaa-mm-jj 00:00:00')
    Type = st.text_input("Select E/S",value="")
    QTEMVT = st.number_input('QTEMVT',step=1)
    MAG = st.text_input('MAG',value='RTCBJA01')
    
#click ajouter
    if st.button('Add Row'):
        df = add_row(df, ART, LIB, Prix_unitaire, MVT, DTMVT, Type, QTEMVT, MAG)
        write_data(df, file_path)
        webbrowser.open_new("http://localhost:8501/data")
#click suprrimer
    if st.button('Remove Row'):
        df = remove_row(df)
        write_data(df, file_path)
        webbrowser.open_new("http://localhost:8501/data")
    index = st.number_input('index pour modifier',step=1)
    #click update
    if st.button('remplir les champs'):
        selected_row = df.loc[index]
        ART1 = st.text_input('ART', value=selected_row['ART'])
        LIB1 = st.text_input('LIB', value=selected_row['LIB'])
        Prix_unitaire1 = st.number_input('Prix unitaire de cession', value=selected_row['Prix unitaire de cession'])
        MVT1 = st.number_input('MVT', step=1, value=selected_row['MVT'])
        DTMVT1 = st.text_input('DTMVT', value=selected_row['DTMVT'])
        Type1 = st.text_input("Select E/S",value = selected_row['TYPE'])
        QTEMVT1 = st.number_input('QTEMVT', step=1, value=selected_row['QTEMVT'])
        
    if st.button('update row'):
          df.at[index, 'ART'] = ART1
          df.at[index, 'LIB'] = LIB1
          df.at[index, 'Prix unitaire de cession'] = Prix_unitaire1
          df.at[index, 'MVT'] = MVT1
          df.at[index, 'DTMVT'] = DTMVT1
          df.at[index, 'TYPE'] = Type1
          df.at[index, 'QTEMVT'] = QTEMVT1
          return df
          write_data(df,file_path)
          webbrowser.open_new("http://localhost:8501/data")
    
if __name__ == '__main__':
    main()