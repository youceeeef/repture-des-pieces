import pandas as pd
import matplotlib.pyplot as plt
import streamlit as st
from sklearn.linear_model import LinearRegression
from datetime import datetime
import seaborn as sns
import numpy as np
import datetime as dt
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
# Charger les données
df = pd.read_excel('SBM.xlsx', sheet_name='Mouvement')

# Renommer les colonnes
df.columns = ['ART', 'LIB', 'Prix unitaire de cession', 'MVT', 'DTMVT', 'TYPE', 'QTEMVT', 'MAG']

# Extraire les ART uniques
arts = df['ART'].unique()

# Afficher une liste de checkbox pour choisir les ART
selected_arts = st.sidebar.multiselect('Choisir les ART', arts)

# Filtrer les données par ART sélectionné
filtered_df = df[df['ART'].isin(selected_arts)]
if st.button('fair un histograme de la piece:',df['ART']):
# Tracer un histogramme de la colonne "date"
 fig, ax = plt.subplots()
 ax.hist(filtered_df.iloc[:, 4], bins=100)
 ax.set_title('Histogramme de la colonne "date"')
 ax.set_xlabel('Date')
 ax.set_ylabel('Nombre d\'occurrences')
 st.pyplot(fig)

# Tri de la colonne de date en ordre croissant
 df.sort_values(df.columns[4], inplace=True)

# Sélection des colonnes pour la régression linéaire
 X = df.iloc[:, 6].values.reshape(-1, 1)  # quantité
 y = df.iloc[:, 4].values  # date

# Instanciation et entraînement du modèle de régression linéaire
 regressor = LinearRegression()
 regressor.fit(X, y)
