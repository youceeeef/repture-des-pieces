import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Charger les données
df = pd.read_excel('SBM.xlsx', sheet_name='Mouvement')

# Renommer les colonnes
df.columns = ['ART', 'LIB', 'Prix unitaire de cession', 'MVT', 'DTMVT', 'TYPE', 'QTEMVT', 'MAG']

# Extraire les ART uniques
arts = df['ART'].unique()

# Afficher une liste de checkbox pour choisir les ART
selected_arts = st.sidebar.multiselect('Choisir les ART', arts)

# Filtrer les données par ART sélectionné
filtered_df = df[df['ART'].isin(selected_arts)]

# Vérifier si le bouton a été cliqué
if st.button('Calculer la durée de vie'):
    # Éliminer les lignes avec TYPE = 'E/CDEH'
    filtered_df = filtered_df[filtered_df['TYPE'] != 'E/CDEH']

    # Trier les données par DTMVT
    filtered_df = filtered_df.sort_values('DTMVT')

    # Calculer la durée de vie
    filtered_df['Durée de vie'] = filtered_df['DTMVT'].diff().shift(-1).dt.days

    # Afficher les statistiques de durée de vie
    st.write('Durée de vie maximale:', filtered_df['Durée de vie'].max())
    st.write('Durée de vie minimale:', filtered_df['Durée de vie'].min())
    st.write('Moyenne des durées de vie:', filtered_df['Durée de vie'].mean())
    st.write('Variance des durées de vie:', filtered_df['Durée de vie'].var())
    st.write('Écart-type des durées de vie:', filtered_df['Durée de vie'].std())

    # Afficher le tableau avec les colonnes ART, LIB, Prix unitaire de cession, MVT, DTMVT, TYPE, QTEMVT, MAG, Durée de vie
    st.write(filtered_df[['ART', 'LIB', 'Prix unitaire de cession', 'MVT', 'DTMVT', 'TYPE', 'QTEMVT', 'MAG', 'Durée de vie']])
  # Vérifier si le bouton a été cliqué
if st.button('Prédiction de la rupture'):
    # Éliminer les lignes avec TYPE = 'E/CDEH'
    filtered_df = filtered_df[filtered_df['TYPE'] != 'E/CDEH']

    # Trier les données par DTMVT
    filtered_df = filtered_df.sort_values('DTMVT')

    # Obtenir les quantités et les dates
    x = filtered_df['QTEMVT'].values.reshape(-1, 1)
    y = (filtered_df['DTMVT'] - filtered_df['DTMVT'].min()).dt.days

    # Créer le modèle de régression linéaire
    model = LinearRegression()
    model.fit(x, y)

    # Obtenir la date de rupture pour une quantité donnée
    q = st.slider('Quantité :', int(filtered_df['QTEMVT'].min()), int(filtered_df['QTEMVT'].max()), int(filtered_df['QTEMVT'].mean()))
    days = model.predict([[q]])[0]
    date = filtered_df['DTMVT'].iloc[0] + pd.Timedelta(days=days, unit='D')

    # Afficher les résultats de la prédiction
    st.write('Quantité :', q)
    st.write('Date de rupture prédite :', date.strftime('%Y-%m-%d'))