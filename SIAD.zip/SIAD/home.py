import streamlit as st
import pandas as pd
import webbrowser
#---sidebare---
def main():
 username = st.text_input("Username")
 password = st.text_input("Password", type='password')

 if st.button("Connect"):
        if username == "admin" and password == "admin":
            webbrowser.open_new("http://localhost:8501/data")
        else:
            st.error("Incorrect username or password")

if __name__ == '__main__':
    main()






